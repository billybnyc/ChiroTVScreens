# Session Keeper — Installer

Installs everything needed to keep ChiroTV Network logged in and refreshed on a
desktop: Python, Playwright, Chromium, the app itself, and the shortcuts.
Nothing needs to be installed beforehand.

Per-user install. No administrator rights required on Windows or macOS.

---

## Windows

Extract the zip, then double-click one of these:

| File | Use it when |
|---|---|
| **Install-Windows.bat** | Normal install — windowed, started manually |
| **Install-Windows-Kiosk-Autostart.bat** | Waiting-room screen — fullscreen, starts itself at login |

That's it. The installer takes five to ten minutes on first run, mostly
downloading Python and Chromium. When it finishes you'll have a **Session
Keeper** shortcut on the Desktop and in the Start Menu.

If Windows SmartScreen warns about the batch file, choose **More info → Run
anyway** — it's unsigned, like any script you write yourself.

## macOS and Linux

```bash
unzip session-keeper-setup.zip
cd session-keeper-setup
chmod +x install-unix.sh
./install-unix.sh                      # normal install
./install-unix.sh --kiosk --autostart  # waiting-room screen
```

Run it with `session-keeper` from any terminal afterwards.

---

## What gets installed where

| | Windows | macOS / Linux |
|---|---|---|
| Application | `%LOCALAPPDATA%\SessionKeeper` | `~/.local/share/session-keeper` |
| Settings | `.env` in that folder | `.env` in that folder (mode 600) |
| Logs | `logs\session_keeper.log` | `logs/session_keeper.log` |
| Screenshots | `logs\screenshots\` | `logs/screenshots/` |
| Python | `%LOCALAPPDATA%\Programs\Python` | system package manager / Homebrew |

Python, Playwright and Chromium live inside the install folder's own virtual
environment, so nothing else on the machine is touched or upgraded.

## Python version

The installer pins **Python 3.13.14**. Python 3.9 reached end of life in
October 2025 and no longer gets security patches, so it isn't a good choice for
a machine that sits on a network unattended. The app itself still runs on 3.9+
if something on your end requires it:

```
powershell -ExecutionPolicy Bypass -File install-windows.ps1 -PythonVersion 3.9.25
```

If the machine already has any Python 3.9 or newer, the installer uses it and
skips the download entirely.

## Installer options

Both installers accept the same flags:

| Flag | Effect |
|---|---|
| `-Kiosk` / `--kiosk` | Fullscreen, no address bar |
| `-AutoStart` / `--autostart` | Start automatically at login |
| `-NoShortcuts` | Skip Desktop and Start Menu shortcuts (Windows) |
| `-InstallDir` / `--install-dir` | Install somewhere other than the default |
| `-PythonVersion` | Pin a different Python (Windows) |

## Re-running and upgrading

Safe to re-run at any time. An existing `.env` is never overwritten, so your
settings survive an upgrade. To reset configuration, delete `.env` from the
install folder and run the installer again.

## Uninstalling

- **Windows:** `powershell -ExecutionPolicy Bypass -File uninstall-windows.ps1`
- **macOS / Linux:** `./uninstall-unix.sh`

Both ask for confirmation and leave Python installed.

## Network requirements

The installing machine needs to reach:

- `python.org` — only if Python isn't already present
- `pypi.org` — the Playwright package
- `cdn.playwright.dev` and `playwright.azureedge.net` — the Chromium download

Behind a corporate firewall, allow those four, or install on an unrestricted
machine and copy the whole install folder across — it's self-contained once
built.

## If something goes wrong

The installer stops at the first failure and prints the reason. The most common
ones:

**"Could not download Python"** — no internet, or a proxy is blocking
python.org. Install Python manually from python.org with "Add python.exe to
PATH" ticked, then re-run.

**"Chromium could not be downloaded"** — network restriction. The message lists
the hosts to allow and the single command to finish the install afterwards.

**"Python installed but can't be located"** — PATH hasn't refreshed. Reboot and
run the installer again.

## Credentials

`.env` contains the ChiroTV username and password in plain text. On macOS and
Linux the installer sets it to mode 600 (owner-only). On Windows it inherits the
user profile's permissions, which keeps it out of other users' reach but not an
administrator's.

To keep the password off disk, delete the `SITE_PASSWORD` line from `.env` and
set `SITE_PASSWORD` as a user environment variable instead. Real environment
variables take priority over `.env`, so no code change is needed.

---

See `app/README.md` for how the keeper itself behaves once it's running — the
refresh cycle, freeze recovery, and the per-site settings worth tuning.
