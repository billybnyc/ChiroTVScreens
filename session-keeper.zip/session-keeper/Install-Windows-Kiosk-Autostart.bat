@echo off
REM Same installer, but for an unattended waiting-room screen:
REM   - fullscreen kiosk mode, no address bar
REM   - starts automatically when the machine logs in

title Session Keeper Installer (kiosk + autostart)
cd /d "%~dp0"

echo.
echo   Installing in kiosk mode with automatic startup  [BUILD v9]...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-windows.ps1" -Kiosk -AutoStart

if errorlevel 1 (
    echo.
    echo   Installation did not complete. See the messages above.
)

echo.
pause
