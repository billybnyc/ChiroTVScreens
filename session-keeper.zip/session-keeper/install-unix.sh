#!/usr/bin/env bash
#
# Session Keeper — macOS / Linux installer
#
# Installs Python if the machine doesn't have a usable version, sets up an
# isolated environment, installs Playwright and Chromium, copies the app into
# place, and optionally registers it to start at login.
#
# Usage:
#   ./install-unix.sh                      # plain install
#   ./install-unix.sh --autostart --kiosk  # unattended screen
#
set -euo pipefail

INSTALL_DIR="${INSTALL_DIR:-$HOME/.local/share/session-keeper}"
PYTHON_VERSION="3.13.14"
MIN_MAJOR=3
MIN_MINOR=9
AUTOSTART=0
KIOSK=0
SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/app"

while [ $# -gt 0 ]; do
    case "$1" in
        --autostart)   AUTOSTART=1 ;;
        --kiosk)       KIOSK=1 ;;
        --install-dir) INSTALL_DIR="$2"; shift ;;
        -h|--help)
            sed -n '3,12p' "$0" | sed 's/^# \{0,1\}//'
            exit 0 ;;
        *) echo "Unknown option: $1" >&2; exit 1 ;;
    esac
    shift
done

say()  { printf '  %s\n' "$1"; }
step() { printf '\n\033[36m==> %s\033[0m\n' "$1"; }
good() { printf '  \033[32m[ok]\033[0m %s\n' "$1"; }
warn() { printf '  \033[33m[!]\033[0m  %s\n' "$1"; }
fail() { printf '\n\033[31mFAILED: %s\033[0m\n' "$1" >&2; exit 1; }

printf '\n  Session Keeper installer\n'
printf '  ------------------------\n'

[ -d "$SOURCE" ] || fail "Can't find the 'app' folder next to this installer. Extract the whole archive first."

case "$(uname -s)" in
    Darwin) OS=mac ;;
    Linux)  OS=linux ;;
    *)      fail "Unsupported system: $(uname -s)" ;;
esac

# ---------------------------------------------------------------------------
# 1. Find or install Python
# ---------------------------------------------------------------------------
step "Checking for Python ${MIN_MAJOR}.${MIN_MINOR} or newer"

find_python() {
    for candidate in python3.14 python3.13 python3.12 python3.11 python3.10 python3.9 python3; do
        if command -v "$candidate" >/dev/null 2>&1; then
            if "$candidate" -c "import sys; raise SystemExit(0 if sys.version_info[:2] >= ($MIN_MAJOR,$MIN_MINOR) else 1)" 2>/dev/null; then
                command -v "$candidate"
                return 0
            fi
        fi
    done
    return 1
}

PYTHON="$(find_python || true)"

if [ -n "$PYTHON" ]; then
    good "Found $("$PYTHON" --version 2>&1) at $PYTHON"
else
    say "No suitable Python found — installing."
    if [ "$OS" = mac ]; then
        if command -v brew >/dev/null 2>&1; then
            say "Installing via Homebrew..."
            brew install python@3.13 || fail "Homebrew install failed."
        else
            fail "Install Python from https://www.python.org/downloads/macos/ (version ${PYTHON_VERSION}), then run this again.
Or install Homebrew first:  /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
        fi
    else
        if command -v apt-get >/dev/null 2>&1; then
            say "Installing via apt (you may be asked for your password)..."
            sudo apt-get update -qq
            sudo apt-get install -y python3 python3-venv python3-pip
        elif command -v dnf >/dev/null 2>&1; then
            sudo dnf install -y python3 python3-pip
        elif command -v pacman >/dev/null 2>&1; then
            sudo pacman -S --noconfirm python python-pip
        else
            fail "Couldn't detect your package manager. Install Python ${MIN_MAJOR}.${MIN_MINOR}+ and run this again."
        fi
    fi
    PYTHON="$(find_python || true)"
    [ -n "$PYTHON" ] || fail "Python installed but still not on PATH. Open a new terminal and run this again."
    good "Installed $("$PYTHON" --version 2>&1)"
fi

# ---------------------------------------------------------------------------
# 2. Copy the application
# ---------------------------------------------------------------------------
step "Installing to $INSTALL_DIR"

mkdir -p "$INSTALL_DIR"
cp "$SOURCE/session_keeper.py"    "$INSTALL_DIR/"
cp "$SOURCE/requirements.txt"     "$INSTALL_DIR/"
cp "$SOURCE/README.md"            "$INSTALL_DIR/"
cp "$SOURCE/config.env.example"   "$INSTALL_DIR/"

if [ -f "$INSTALL_DIR/.env" ]; then
    warn "Existing .env kept — your settings were not overwritten."
else
    cp "$SOURCE/config.env" "$INSTALL_DIR/.env"
    chmod 600 "$INSTALL_DIR/.env"      # the file holds a password
    good "Configuration written to .env"
fi
good "Application files copied"

# ---------------------------------------------------------------------------
# 3. Virtual environment and dependencies
# ---------------------------------------------------------------------------
step "Setting up the Python environment"

VENV="$INSTALL_DIR/.venv"
if [ ! -x "$VENV/bin/python" ]; then
    "$PYTHON" -m venv "$VENV" || fail "Could not create the virtual environment.
On Debian/Ubuntu you may need:  sudo apt-get install python3-venv"
    good "Virtual environment created"
else
    good "Virtual environment already present"
fi

say "Installing Playwright (a few minutes on first run)..."
"$VENV/bin/python" -m pip install --upgrade pip --quiet
"$VENV/bin/python" -m pip install -r "$INSTALL_DIR/requirements.txt" --quiet \
    || fail "pip install failed. Check your internet connection and try again."
good "Python packages installed"

say "Downloading the Chromium browser (~150 MB)..."
install_chromium() {
    if [ "$OS" = linux ] && command -v sudo >/dev/null 2>&1; then
        # Linux needs system libraries for Chromium; --with-deps pulls them in.
        "$VENV/bin/python" -m playwright install --with-deps chromium && return 0
    fi
    "$VENV/bin/python" -m playwright install chromium
}

CHROMIUM_OK=0
for attempt in 1 2 3; do
    if install_chromium > "$INSTALL_DIR/chromium-install.log" 2>&1; then
        CHROMIUM_OK=1
        break
    fi
    if [ "$attempt" -lt 3 ]; then
        warn "Download attempt $attempt failed - retrying in 5s..."
        sleep 5
    fi
done

if [ "$CHROMIUM_OK" = 0 ]; then
    fail "Chromium could not be downloaded after 3 attempts.

Full log: $INSTALL_DIR/chromium-install.log

This is almost always a network restriction. These hosts must be reachable:
    cdn.playwright.dev
    playwright.azureedge.net
    pypi.org

If this machine is behind a corporate firewall or proxy, allow those hosts,
then finish the install by running:
    $VENV/bin/python -m playwright install chromium"
fi
rm -f "$INSTALL_DIR/chromium-install.log"
good "Chromium installed"

# ---------------------------------------------------------------------------
# 4. Launcher
# ---------------------------------------------------------------------------
step "Creating the launcher"

RUNNER="$INSTALL_DIR/start-session-keeper.sh"
cat > "$RUNNER" << RUNNER_EOF
#!/usr/bin/env bash
cd "\$(dirname "\$0")"
# Exit code 86 means the keeper updated itself and wants to restart.
while true; do
    .venv/bin/python session_keeper.py
    code=\$?
    if [ "\$code" != "86" ]; then
        exit "\$code"
    fi
    echo "Update installed - restarting Session Keeper..."
    sleep 3
done
RUNNER_EOF
chmod +x "$RUNNER"

mkdir -p "$HOME/.local/bin"
ln -sf "$RUNNER" "$HOME/.local/bin/session-keeper"
good "Launcher created (run 'session-keeper' from a terminal)"

if [ "$KIOSK" = 1 ]; then
    if command -v sed >/dev/null 2>&1; then
        sed -i.bak 's/^KIOSK=.*/KIOSK=true/' "$INSTALL_DIR/.env" && rm -f "$INSTALL_DIR/.env.bak"
        good "Kiosk mode enabled"
    fi
fi

# ---------------------------------------------------------------------------
# 5. Start at login
# ---------------------------------------------------------------------------
if [ "$AUTOSTART" = 1 ]; then
    step "Registering to start at login"
    if [ "$OS" = mac ]; then
        PLIST="$HOME/Library/LaunchAgents/com.sessionkeeper.plist"
        mkdir -p "$(dirname "$PLIST")"
        cat > "$PLIST" << PLIST_EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key><string>com.sessionkeeper</string>
    <key>ProgramArguments</key>
    <array><string>$RUNNER</string></array>
    <key>RunAtLoad</key><true/>
    <key>KeepAlive</key><true/>
    <key>StandardOutPath</key><string>$INSTALL_DIR/logs/launchd.out.log</string>
    <key>StandardErrorPath</key><string>$INSTALL_DIR/logs/launchd.err.log</string>
</dict>
</plist>
PLIST_EOF
        mkdir -p "$INSTALL_DIR/logs"
        launchctl unload "$PLIST" 2>/dev/null || true
        launchctl load "$PLIST"
        good "Registered as a launch agent (starts at login, restarts if it exits)"
    else
        DESKTOP="$HOME/.config/autostart/session-keeper.desktop"
        mkdir -p "$(dirname "$DESKTOP")"
        cat > "$DESKTOP" << DESKTOP_EOF
[Desktop Entry]
Type=Application
Name=Session Keeper
Comment=Keeps ChiroTV logged in and refreshed
Exec=$RUNNER
Terminal=false
X-GNOME-Autostart-enabled=true
DESKTOP_EOF
        good "Autostart entry created"
    fi
fi

# ---------------------------------------------------------------------------
printf '\n  \033[32mInstallation complete.\033[0m\n\n'
say "Installed to:  $INSTALL_DIR"
say "Start it:      session-keeper        (or $RUNNER)"
say "Settings:      $INSTALL_DIR/.env"
say "Logs:          $INSTALL_DIR/logs"
if [ "$AUTOSTART" = 0 ]; then
    printf '\n'
    say "To start it automatically at login, re-run with --autostart"
fi
printf '\n'
