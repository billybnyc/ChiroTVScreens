#!/usr/bin/env python3
"""
make_manifest.py - build the manifest the screens read.

Run this on your own machine whenever you want to push a change. It hashes
the script, bumps the version, and writes manifest.json ready to upload.

    python make_manifest.py --base-url https://example.com/chirotv
    python make_manifest.py --base-url https://... --set FINAL_KEYS=Escape
    python make_manifest.py --base-url https://... --settings-only

Then upload manifest.json (and session_keeper.py when the code changed) to
that base URL. The screens pick it up at their next check.
"""
import argparse
import datetime
import hashlib
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
DEFAULT_SCRIPT = HERE.parent / "app" / "session_keeper.py"


def next_version(out_path):
    stamp = datetime.date.today().strftime("%Y%m%d")
    previous = {}
    if out_path.is_file():
        try:
            previous = json.loads(out_path.read_text(encoding="utf-8"))
        except ValueError:
            pass
    last = str(previous.get("version", ""))
    if last.startswith(stamp + "."):
        try:
            return "%s.%d" % (stamp, int(last.split(".")[1]) + 1)
        except ValueError:
            pass
    return "%s.1" % stamp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", required=True,
                    help="Public URL of the folder holding manifest.json and the script")
    ap.add_argument("--script", type=pathlib.Path, default=DEFAULT_SCRIPT,
                    help="Path to the session_keeper.py being published")
    ap.add_argument("--version", help="Version label (default: today plus a counter)")
    ap.add_argument("--note", default="", help="One line shown in each screen's log")
    ap.add_argument("--set", action="append", default=[], metavar="KEY=VALUE",
                    help="A setting to push; repeatable")
    ap.add_argument("--settings-only", action="store_true",
                    help="Push settings without offering a new script")
    ap.add_argument("--out", type=pathlib.Path, default=HERE / "manifest.json")
    args = ap.parse_args()

    base = args.base_url.rstrip("/")
    manifest = {"version": args.version or next_version(args.out)}

    if args.note:
        manifest["note"] = args.note

    if not args.settings_only:
        if not args.script.is_file():
            sys.exit("Script not found: %s" % args.script)
        data = args.script.read_bytes()

        # Never publish a script that does not compile.
        import py_compile
        import tempfile
        tmp = pathlib.Path(tempfile.mkdtemp()) / "candidate.py"
        tmp.write_bytes(data)
        try:
            py_compile.compile(str(tmp), doraise=True)
        except Exception as exc:
            sys.exit("Refusing to publish - the script does not compile:\n%s" % exc)

        nonascii = sum(1 for b in data if b > 127)
        if nonascii:
            print("  warning: the script contains %d non-ASCII byte(s)" % nonascii)

        manifest["script"] = {
            "url": base + "/session_keeper.py",
            "sha256": hashlib.sha256(data).hexdigest(),
        }

    settings = {}
    for pair in args.set:
        if "=" not in pair:
            sys.exit("--set needs KEY=VALUE, got: %s" % pair)
        key, value = pair.split("=", 1)
        settings[key.strip().upper()] = value
    if settings:
        manifest["settings"] = settings

    args.out.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    print("Wrote %s" % args.out)
    print("  version : %s" % manifest["version"])
    if "script" in manifest:
        print("  script  : %s" % manifest["script"]["url"])
        print("  sha256  : %s" % manifest["script"]["sha256"])
    if settings:
        print("  settings: %s" % ", ".join(sorted(settings)))
    print("")
    print("Upload to %s/ :" % base)
    print("  manifest.json")
    if "script" in manifest:
        print("  session_keeper.py")


if __name__ == "__main__":
    main()
