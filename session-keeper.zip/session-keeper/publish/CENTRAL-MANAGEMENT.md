# Managing the screens centrally

Once a screen is running, you change it by editing one file on a web server
instead of visiting the machine. Each screen checks that file when it starts
and again at every 24-hour restart, so a change reaches them all within a day
(or immediately, if you restart one).

## What you can push

**Settings** — any value from `.env`: the play-button labels, `FINAL_KEYS`,
timings, kiosk mode, the site URL. These land in `central.env` on each machine
and take priority over the local `.env`.

**The script itself** — a whole new `session_keeper.py`. The screen downloads
it, checks it, installs it and restarts into it.

**Not credentials, by default.** `SITE_USERNAME` and `SITE_PASSWORD` in a
manifest are ignored unless a machine has `UPDATE_ALLOW_CREDENTIALS=true`.
That keeps the password off a web server you might later make public. If your
host is private and you want central credential rotation, turn it on.

**Not machine-local keys.** `PROFILE_DIR` and `UPDATE_MANIFEST_URL` are always
ignored from the manifest — pushing those would point every screen at one
profile folder, or cut them all off from future updates.

## Where to host it

Any HTTPS URL that serves two static files. In rough order of convenience:

| Host | Good for | Notes |
|---|---|---|
| **GitHub repo (raw URL)** | Most cases | Free, versioned, rollback is a git revert. Use a private repo plus a token in the URL if you'd rather it wasn't public. |
| **Cloudflare R2 / S3 / Azure Blob** | More screens | Static hosting, cheap, no repo. |
| **A folder on a site you already run** | Simplest | If you have web hosting, it's a folder and an upload. |
| **Your RMM's script distribution** | If you already run one | Different model — the RMM pushes files rather than the screen pulling them. Set `UPDATE_MANIFEST_URL=` blank and let the RMM own it. |

For GitHub, the raw URL looks like:

```
https://raw.githubusercontent.com/<you>/<repo>/main/manifest.json
```

Put that in each machine's `.env` as `UPDATE_MANIFEST_URL`. It is the one
setting that has to be right on the machine before central control works.

## Publishing a change

From this `publish/` folder on your own machine:

```bash
# Settings change only - no new code
python make_manifest.py --base-url https://your-host/chirotv \
    --settings-only \
    --set FINAL_KEYS=Escape \
    --set CHECK_MINUTES=15

# New script as well
python make_manifest.py --base-url https://your-host/chirotv \
    --note "fix the second play button label"
```

It writes `manifest.json` with a fresh version number and the script's
checksum. Upload `manifest.json` — plus `session_keeper.py` when the code
changed — to that URL. Done.

The version auto-increments per day (`20261031.1`, `20261031.2`), so you don't
have to track it. A screen only acts when the version differs from what it
last applied.

## What a manifest looks like

```json
{
  "version": "20261031.1",
  "note": "shown once in each screen's log",
  "script": {
    "url": "https://your-host/chirotv/session_keeper.py",
    "sha256": "0d59d642a2c6838833178d27f1e1ff007e0eef1dbfa1f0310ddaba044e1a0c8a"
  },
  "settings": {
    "FINAL_KEYS": "Escape",
    "POST_LOGIN_CLICKS": "Play ChiroTV|Play the newest version of ChiroTV Network"
  }
}
```

Every field is optional except `version`. Settings alone, script alone, or both.

## Why a bad push won't take the screens down

Four things have to go right before a downloaded script replaces a running one:

1. **It downloads.** If the server is unreachable, the screen logs a warning
   and carries on with what it has. An outage on your web host is not an
   outage on the waiting-room TVs.
2. **The checksum matches**, when the manifest carries one. `make_manifest.py`
   always writes one.
3. **It compiles.** The screen runs `py_compile` on the download before
   installing it. A syntax error is refused and the running script is untouched.
   `make_manifest.py` makes the same check before publishing, so you'd normally
   catch it first.
4. **The swap succeeds.** The previous script is kept as `session_keeper.py.bak`
   and restored if the replacement cannot be put in place.

Each screen logs every step of this to `logs/session_keeper.log`.

## Rolling back

Publish the previous script again with a new version number. The screens take
it on their next check, the same as any other update.

In a hurry on one machine: stop it, rename `session_keeper.py.bak` over
`session_keeper.py`, and clear `UPDATE_MANIFEST_URL` in its `.env` so it does
not immediately pull the bad version again.

## The security position, plainly

Whoever can write to that URL can run code on every screen that reads it.
That is what auto-update means, and no amount of checksumming changes it —
the checksum lives in the same file as the code it vouches for.

What follows from that:

- Use **https**, never plain http.
- Host it somewhere only you can write: a private repo, your own bucket,
  your own server. Not a shared drive, not a public wiki.
- The screens send no secrets to the update server — they only fetch.
- If the host is ever compromised, the fix is to clear `UPDATE_MANIFEST_URL`
  on the machines and reinstall from a known-good zip.

For a handful of waiting-room TVs on a clinic network this is a reasonable
trade. If these were machines handling patient data, the calculus would be
different and the update source would want signing rather than a bare hash.
