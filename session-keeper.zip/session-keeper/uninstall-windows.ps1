<#
    Session Keeper - Windows uninstaller.
    Removes the install folder and shortcuts. Leaves Python installed.
    This file is deliberately pure ASCII (see install-windows.ps1 for why).
#>
param([string] $InstallDir = "$env:LOCALAPPDATA\SessionKeeper")

Write-Host ""
Write-Host "  This will remove Session Keeper from:" -ForegroundColor Yellow
Write-Host "    $InstallDir"
Write-Host ""
$answer = Read-Host "  Type YES to confirm"
if ($answer -ne "YES") {
    Write-Host "  Cancelled."
    exit 0
}

$folders = @(
    [Environment]::GetFolderPath("Desktop"),
    (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"),
    (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup")
)

foreach ($folder in $folders) {
    $lnk = Join-Path $folder "Session Keeper.lnk"
    if (Test-Path $lnk) {
        Remove-Item $lnk -Force
        Write-Host "  Removed shortcut: $lnk"
    }
}

if (Test-Path $InstallDir) {
    Remove-Item $InstallDir -Recurse -Force
    Write-Host "  Removed $InstallDir"
}

Write-Host ""
Write-Host "  Done. Python itself was left installed." -ForegroundColor Green
Write-Host ""
