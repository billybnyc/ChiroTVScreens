<#
    Session Keeper - Windows installer

    Installs Python if the machine doesn't have a usable version, sets up an
    isolated environment, installs Playwright and Chromium, copies the app into
    place, and creates the shortcuts.

    Per-user install - no administrator rights needed.

    NOTE: This file is deliberately pure ASCII. Windows PowerShell 5.1 reads
    .ps1 files as Windows-1252 unless they carry a BOM, and a UTF-8 em dash
    decodes into a character PowerShell treats as a quote, which breaks parsing.

    Usage (normally via Install-Windows.bat):
        powershell -ExecutionPolicy Bypass -File install-windows.ps1
        powershell -ExecutionPolicy Bypass -File install-windows.ps1 -AutoStart -Kiosk
#>

[CmdletBinding()]
param(
    [string] $InstallDir    = "$env:LOCALAPPDATA\SessionKeeper",
    [string] $PythonVersion = "3.13.14",
    [switch] $AutoStart,
    [switch] $Kiosk,
    [switch] $NoShortcuts
)

$ErrorActionPreference = "Stop"
$MinPython = [version]"3.9.0"
$Source    = Join-Path $PSScriptRoot "app"

# PowerShell 5.1 defaults to TLS 1.0, which python.org and pypi.org refuse.
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
} catch {
    Write-Host "  Note: could not raise TLS level; downloads may fail on old systems."
}

function Say  ($m) { Write-Host "  $m" }
function Step ($m) { Write-Host ""; Write-Host "==> $m" -ForegroundColor Cyan }
function Good ($m) { Write-Host "  [ok] $m" -ForegroundColor Green }
function Warn ($m) { Write-Host "  [!]  $m" -ForegroundColor Yellow }
function Fail ($m) {
    Write-Host ""
    Write-Host "FAILED: $m" -ForegroundColor Red
    Write-Host ""
    exit 1
}

$BuildId = "v9 (2026-10-31, verified central update URL)"

Write-Host ""
Write-Host "  Session Keeper installer $BuildId" -ForegroundColor White
Write-Host "  --------------------------------------------"
Write-Host "  If this line does not say v9, you are running an old copy." -ForegroundColor Yellow
Write-Host "  Delete the old folder and extract the new zip fresh."

if (-not (Test-Path $Source)) {
    Fail "Cannot find the 'app' folder next to this installer. Extract the whole zip before running it."
}

# ---------------------------------------------------------------------------
# 1. Find or install Python
# ---------------------------------------------------------------------------
Step "Checking for Python $MinPython or newer"

function Get-PythonPath {
    $candidates = @()

    # The py launcher is the most reliable way to find a real CPython install.
    $pyCmd = Get-Command py -ErrorAction SilentlyContinue
    if ($pyCmd) {
        try {
            $found = & py -3 -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $found) { $candidates += $found.Trim() }
        } catch { }
    }

    foreach ($name in @("python", "python3")) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue
        if ($cmd) { $candidates += $cmd.Source }
    }

    foreach ($candidate in $candidates) {
        # Skip the Microsoft Store stub, which exits without doing anything.
        if ($candidate -like "*WindowsApps*") { continue }
        try {
            $ver = & $candidate -c "import sys; print('%d.%d.%d' % sys.version_info[:3])" 2>$null
            if ($LASTEXITCODE -eq 0 -and $ver) {
                $parsed = [version]$ver.Trim()
                if ($parsed -ge $MinPython) {
                    return New-Object PSObject -Property @{ Path = $candidate; Version = $ver.Trim() }
                }
            }
        } catch { }
    }
    return $null
}

$python = Get-PythonPath

if ($python -ne $null) {
    Good ("Found Python " + $python.Version + " at " + $python.Path)
} else {
    Say "No suitable Python found. Installing $PythonVersion."

    if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") { $arch = "arm64" } else { $arch = "amd64" }
    $fileName = "python-$PythonVersion-$arch.exe"
    $url      = "https://www.python.org/ftp/python/$PythonVersion/$fileName"
    $dest     = Join-Path $env:TEMP $fileName

    Say "Downloading $url"
    try {
        $ProgressPreference = "SilentlyContinue"
        Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing
    } catch {
        $downloadError = $_.Exception.Message
        $msg = @"
Could not download Python.

  $downloadError

If this machine is behind a proxy or has no internet access, install Python
manually from https://www.python.org/downloads/ (tick "Add python.exe to
PATH"), then run this installer again.
"@
        Fail $msg
    }

    $sizeMb = [math]::Round((Get-Item $dest).Length / 1MB, 1)
    Good "Downloaded $sizeMb MB"

    Say "Installing (silent, current user only). This takes a minute..."
    $installArgs = @(
        "/quiet",
        "InstallAllUsers=0",
        "PrependPath=1",
        "Include_pip=1",
        "Include_test=0",
        "Include_launcher=1"
    )
    $proc = Start-Process -FilePath $dest -ArgumentList $installArgs -Wait -PassThru
    if ($proc.ExitCode -ne 0) {
        Fail "The Python installer exited with code $($proc.ExitCode)."
    }
    Remove-Item $dest -ErrorAction SilentlyContinue

    # Refresh PATH for this process so the new install is visible immediately.
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath    = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path    = "$machinePath;$userPath"

    $python = Get-PythonPath
    if ($python -eq $null) {
        $shortVer = $PythonVersion.Split(".")[0] + $PythonVersion.Split(".")[1]
        $guess = Join-Path $env:LOCALAPPDATA "Programs\Python\Python$shortVer\python.exe"
        if (Test-Path $guess) {
            $python = New-Object PSObject -Property @{ Path = $guess; Version = $PythonVersion }
        } else {
            Fail "Python installed but cannot be located. Reboot and run this installer again."
        }
    }
    Good ("Installed Python " + $python.Version)
}

# ---------------------------------------------------------------------------
# 2. Copy the application
# ---------------------------------------------------------------------------
Step "Installing to $InstallDir"

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item (Join-Path $Source "session_keeper.py")  $InstallDir -Force
Copy-Item (Join-Path $Source "requirements.txt")   $InstallDir -Force
Copy-Item (Join-Path $Source "README.md")          $InstallDir -Force
Copy-Item (Join-Path $Source "config.env.example") $InstallDir -Force

# central.env is written by the update check, never shipped. Remove a stale
# one from an older install so old pushed settings cannot linger.
$staleCentral = Join-Path $InstallDir "central.env"
if ((Test-Path $staleCentral) -and -not (Test-Path (Join-Path $InstallDir "update_state.json"))) {
    Remove-Item $staleCentral -Force -ErrorAction SilentlyContinue
}

# Never clobber a config that has already been customised on this machine.
$envFile = Join-Path $InstallDir ".env"
if (Test-Path $envFile) {
    Warn "Existing .env kept. Your settings were not overwritten."
} else {
    Copy-Item (Join-Path $Source "config.env") $envFile -Force
    Good "Configuration written to .env"
}
Good "Application files copied"

# Report which build of the keeper script actually landed, so there is never
# any doubt about whether an old copy is still in place.
$buildLine = Select-String -Path (Join-Path $InstallDir "session_keeper.py") -Pattern 'SCRIPT_BUILD = "(.+)"' -EA SilentlyContinue
if ($buildLine) {
    Good ("Keeper script build: " + $buildLine.Matches[0].Groups[1].Value)
} else {
    Warn "Could not read the keeper script build marker."
}

# ---------------------------------------------------------------------------
# 3. Virtual environment and dependencies
# ---------------------------------------------------------------------------
Step "Setting up the Python environment"

$venv       = Join-Path $InstallDir ".venv"
$venvPython = Join-Path $venv "Scripts\python.exe"

if (-not (Test-Path $venvPython)) {
    & $python.Path -m venv $venv
    if ($LASTEXITCODE -ne 0) { Fail "Could not create the virtual environment." }
    Good "Virtual environment created"
} else {
    Good "Virtual environment already present"
}

Say "Installing Playwright. A few minutes on first run..."
& $venvPython -m pip install --upgrade pip --quiet
& $venvPython -m pip install -r (Join-Path $InstallDir "requirements.txt") --quiet
if ($LASTEXITCODE -ne 0) {
    Fail "pip install failed. Check your internet connection and try again."
}
Good "Python packages installed"

Say "Downloading the Chromium browser (about 150 MB)..."
$chromiumLog = Join-Path $InstallDir "chromium-install.log"
$chromiumOk  = $false

foreach ($attempt in 1..3) {
    & $venvPython -m playwright install chromium 2>&1 | Out-File -FilePath $chromiumLog -Encoding UTF8
    if ($LASTEXITCODE -eq 0) {
        $chromiumOk = $true
        break
    }
    if ($attempt -lt 3) {
        Warn "Download attempt $attempt failed. Retrying in 5 seconds..."
        Start-Sleep -Seconds 5
    }
}

if (-not $chromiumOk) {
    $msg = @"
Chromium could not be downloaded after 3 attempts.

Full log: $chromiumLog

This is almost always a network restriction. These hosts must be reachable:
    cdn.playwright.dev
    playwright.azureedge.net
    pypi.org

If this machine is behind a corporate firewall or proxy, allow those hosts,
then finish the install by running this one command:

    "$venvPython" -m playwright install chromium
"@
    Fail $msg
}
Remove-Item $chromiumLog -ErrorAction SilentlyContinue
Good "Chromium installed"

# ---------------------------------------------------------------------------
# 4. Launcher
# ---------------------------------------------------------------------------
Step "Creating the launcher"

$runner = Join-Path $InstallDir "Start Session Keeper.bat"
$runnerLines = @(
    '@echo off',
    'title Session Keeper',
    'cd /d "%~dp0"',
    '',
    'REM Exit code 86 means the keeper updated itself and wants to restart.',
    'REM Anything else means it genuinely stopped.',
    ':runloop',
    '".venv\Scripts\python.exe" session_keeper.py',
    'if errorlevel 87 goto finished',
    'if errorlevel 86 (',
    '    echo.',
    '    echo Update installed - restarting Session Keeper...',
    '    timeout /t 3 /nobreak >nul',
    '    goto runloop',
    ')',
    '',
    ':finished',
    'echo.',
    'echo Session Keeper has stopped. Press any key to close.',
    'pause >nul'
)
Set-Content -Path $runner -Value $runnerLines -Encoding ASCII
Good "Launcher created"

if ($Kiosk) {
    $cfg = Get-Content $envFile -Raw
    $cfg = $cfg -replace '(?m)^KIOSK=.*$', 'KIOSK=true'
    Set-Content -Path $envFile -Value $cfg -Encoding UTF8
    Good "Kiosk mode enabled"
}

# ---------------------------------------------------------------------------
# 5. Shortcuts
# ---------------------------------------------------------------------------
if (-not $NoShortcuts) {
    Step "Creating shortcuts"
    $shell = New-Object -ComObject WScript.Shell

    function New-SessionShortcut ($folder, $label) {
        if (-not (Test-Path $folder)) { New-Item -ItemType Directory -Force -Path $folder | Out-Null }
        $linkPath = Join-Path $folder "Session Keeper.lnk"
        $lnk = $shell.CreateShortcut($linkPath)
        $lnk.TargetPath       = $runner
        $lnk.WorkingDirectory = $InstallDir
        $lnk.Description      = "Keeps ChiroTV logged in and refreshed"
        $lnk.Save()
        Good "$label shortcut created"
    }

    New-SessionShortcut ([Environment]::GetFolderPath("Desktop")) "Desktop"

    $startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
    New-SessionShortcut $startMenu "Start Menu"

    if ($AutoStart) {
        $startup = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup"
        New-SessionShortcut $startup "Startup (runs at login)"
    }
}

# ---------------------------------------------------------------------------
# Done
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "  Installation complete." -ForegroundColor Green
Write-Host ""
Say "Installed to:  $InstallDir"
Say "Start it:      double-click 'Session Keeper' on the Desktop"
Say "Settings:      $envFile"
Say "Logs:          $InstallDir\logs"

if (-not $AutoStart) {
    Write-Host ""
    Say "To run it automatically at login, re-run this installer with -AutoStart"
    Say "or copy the Desktop shortcut into shell:startup."
}
Write-Host ""
