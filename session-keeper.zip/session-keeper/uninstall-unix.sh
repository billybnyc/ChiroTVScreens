#!/usr/bin/env bash
# Session Keeper — macOS / Linux uninstaller.
set -euo pipefail
INSTALL_DIR="${INSTALL_DIR:-$HOME/.local/share/session-keeper}"

printf '\n  This will remove Session Keeper from:\n    %s\n\n' "$INSTALL_DIR"
read -r -p "  Type YES to confirm: " answer
[ "$answer" = "YES" ] || { echo "  Cancelled."; exit 0; }

PLIST="$HOME/Library/LaunchAgents/com.sessionkeeper.plist"
if [ -f "$PLIST" ]; then
    launchctl unload "$PLIST" 2>/dev/null || true
    rm -f "$PLIST"
    echo "  Removed launch agent"
fi

rm -f "$HOME/.config/autostart/session-keeper.desktop"
rm -f "$HOME/.local/bin/session-keeper"
rm -rf "$INSTALL_DIR"

printf '\n  Done. Python itself was left installed.\n\n'
