@echo off
REM Session Keeper - double-click this file to install on Windows.
REM It just launches the PowerShell installer with the right flags.

title Session Keeper Installer
cd /d "%~dp0"

echo.
echo   Starting the Session Keeper installer  [BUILD v9]...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-windows.ps1" %*

if errorlevel 1 (
    echo.
    echo   Installation did not complete. See the messages above.
)

echo.
pause
