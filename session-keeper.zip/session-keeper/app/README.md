# Session Keeper

Keeps a site open in a visible browser window on a desktop, quits and relaunches the browser every 24 hours, and logs back in whenever the session has dropped. Recovers on its own from frozen pages and session-timeout modals.

Runs the same way on Windows, macOS and Linux. **This copy is preconfigured for ChiroTV Network** — the `.env` file already has the site URL and the ChiroTV credentials in it, so there's nothing to fill in before the first run.

## Running it on a desktop

1. Install Python 3.9 or newer and make sure it's on PATH.
2. Copy this whole folder to the machine, `.env` included.
3. Start it:
   - **Windows:** double-click `run.bat`
   - **macOS / Linux:** `chmod +x run.sh && ./run.sh`

The launcher creates a virtual environment, installs Playwright and its bundled Chromium, then starts the keeper. Everything after the first run reuses that environment, so startup is fast.

Stop it with Ctrl+C in the window it's running in.

### One change worth making first

`SITE_URL` in `.env` currently points at the login page. Log in manually once, navigate to the page the TV should actually display, and paste that URL in as `SITE_URL`. The script will then go straight there each cycle and only detour through the login form when the session has genuinely dropped.

### Deploying to the other desktops

Copy the folder — including `.env` — but skip `profile/`, `logs/` and `.venv/`. Each machine rebuilds those on its first run. Because the credentials travel in `.env`, no per-machine setup is needed.

If you'd rather not have the password sitting in a file on every machine, delete the `SITE_PASSWORD` line from `.env` and set `SITE_PASSWORD` as a user environment variable instead (Windows: System Properties → Environment Variables; macOS/Linux: export it from your shell profile). Real environment variables take priority over `.env`, so the script picks it up with no code change.

`.gitignore` already excludes `.env`, but that only protects you if the folder is a git repo. If you're moving it around on a USB stick or a shared drive, that's the copy to keep track of.

## What happens on each check

Every `CHECK_MINUTES` (default 15) the script runs through this sequence:

1. **Health probe.** It asks the page's own JavaScript to answer a trivial question within `HEALTH_TIMEOUT_MS`. If the thread is hung, no answer comes back and the page is treated as frozen.
2. **Recovery ladder**, if the probe failed — each step heavier than the last:
   - reload the page
   - navigate to `about:blank`, then back to the site (discards the document)
   - close the tab and open a new one (kills the hung renderer process, which a reload cannot do)
   - if all three fail, quit the browser entirely and start a fresh cycle
3. **Overlay handling.** Checks for a keep-alive button, then a log-back-in button, then a generic dismiss target. First match wins.
4. **Routine reload**, unless a keep-alive was just clicked — no point throwing away a session you just renewed.
5. **Login check**, and a full login if needed.

Three consecutive failed checks trigger an early browser restart rather than waiting out the 24 hours. Native `alert()` / `confirm()` dialogs are auto-dismissed, since an unanswered one blocks navigation and looks identical to a freeze.

Logs go to `logs/session_keeper.log`. Screenshots of anything that went wrong go to `logs/screenshots/` (last 30 kept) — that's usually the fastest way to work out what a site is actually doing at 3am.

## How it logs in

ChiroTV's login form doesn't expose its field names to the outside, so the script doesn't rely on them. It finds the password field, takes the visible text input directly above it as the username box, and submits with Enter if it doesn't recognise a submit button. That pattern holds up on old hand-rolled PHP forms like this one.

If it ever misses, run it once, look at `logs/screenshots/` to see what it was staring at, and set `USERNAME_SELECTOR` and `SUBMIT_SELECTOR` explicitly in `.env`.

## Settings worth revisiting later

**`LOGGED_IN_SELECTOR`** — currently blank, so the script falls back to "a visible password field means we're logged out." That's reliable here. To tighten it, log in manually, right-click something that only appears when signed in (a logout link, an account name), Inspect, copy its CSS selector, and put it here.

**`KEEPALIVE_SELECTOR`** — if the site pops a "your session is about to expire" modal with a Continue button, put that button here. Clicking it renews the existing session, which is always better than logging in again. Playwright supports text matching, so `button:has-text("Continue")` works without needing a stable id.

**`RELOGIN_SELECTOR`** — for an expired-session modal that hides the login form behind a "Log back in" button. Without it the script sees no password field and wrongly concludes everything is fine.

**`DISMISS_SELECTOR`** — cookie banners, terms notices, or a Cancel button on a stuck dialog.

All three modal settings are commented out in `.env`, since what ChiroTV actually shows on timeout isn't known yet. Let it run a couple of days, check the screenshots for whatever appears, then fill them in. You can list several comma-separated alternatives in one setting; the first visible match is used.

## Starting it automatically at login

- **Windows:** put a shortcut to `run.bat` in `shell:startup`.
- **macOS:** System Settings → General → Login Items → add `run.sh`.
- **Linux:** add a `.desktop` entry in `~/.config/autostart/` pointing at `run.sh`.

Because the script holds its own 24-hour timer, there's nothing to schedule beyond getting it started once.

## Browser choice

By default it uses Playwright's bundled Chromium, which is the most portable option since it doesn't depend on what's installed. If you want the machine's real Chrome or Edge — for existing profiles, extensions, or enterprise policy — set `BROWSER_CHANNEL=chrome` or `BROWSER_CHANNEL=msedge`. Set `KIOSK=true` for fullscreen with no address bar, which is usually what you want on a waiting-room screen.

## Known limit

If the entire browser process wedges — not just the page — `context.close()` can hang. The script logs that and the outer loop still starts a fresh browser, but the dead process may linger. On an unattended screen it's worth having the OS restart the whole script daily as a backstop.
