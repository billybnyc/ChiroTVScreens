@echo off
REM Session Keeper - normal window, starts automatically at Windows login.

title Session Keeper Installer (autostart)
cd /d "%~dp0"

echo.
echo   Installing with automatic startup at login  [BUILD v9]...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-windows.ps1" -AutoStart

if errorlevel 1 (
    echo.
    echo   Installation did not complete. See the messages above.
)

echo.
pause
